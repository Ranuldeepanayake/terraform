const os = require("os");

exports.handler = async (event) => {
  const response = {
    hostname: os.hostname(),
    timestamp: new Date().toISOString(),
    runtime: process.version
  };

  console.log(JSON.stringify(response));

  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(response)
  };
};
